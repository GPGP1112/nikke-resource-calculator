extends RefCounted
## Local progression data. No server/network features in this prototype.

const SAVE_PATH := "user://survivor_save_v01.json"
const IDLE_RATE_PER_HOUR := 120.0
const MAX_IDLE_SECONDS := 28800

static func default_data() -> Dictionary:
    return {
        "gold": 0,
        "attack_level": 0,
        "health_level": 0,
        "stage": 1,
        "wins": 0,
        "pending_idle": 0,
        "last_seen": int(Time.get_unix_time_from_system())
    }

static func load_data() -> Dictionary:
    var result := default_data()
    if FileAccess.file_exists(SAVE_PATH):
        var file := FileAccess.open(SAVE_PATH, FileAccess.READ)
        if file != null:
            var decoded: Variant = JSON.parse_string(file.get_as_text())
            if decoded is Dictionary:
                for key in result.keys():
                    if decoded.has(key) and (typeof(decoded[key]) == TYPE_INT or typeof(decoded[key]) == TYPE_FLOAT):
                        result[key] = maxi(0, int(decoded[key]))
    var now := int(Time.get_unix_time_from_system())
    # Clock rollback cannot grant extra gold. Server-side validation is needed later.
    var elapsed := clampi(now - int(result["last_seen"]), 0, MAX_IDLE_SECONDS)
    var reward := int(floor(float(elapsed) * IDLE_RATE_PER_HOUR / 3600.0))
    result["pending_idle"] = int(result["pending_idle"]) + reward
    result["last_seen"] = now
    write_data(result)
    return result

static func write_data(data: Dictionary) -> bool:
    data["last_seen"] = int(Time.get_unix_time_from_system())
    var file := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
    if file == null:
        push_warning("Could not write save file: " + str(FileAccess.get_open_error()))
        return false
    file.store_string(JSON.stringify(data, "  "))
    file.close()
    return true

static func upgrade_cost(level: int) -> int:
    return int(ceil(20.0 * pow(1.18, float(level))))
