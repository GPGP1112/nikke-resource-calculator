extends Control
## Self-contained, data-driven survival battle. Art is rendered procedurally.

signal level_up_requested
signal battle_finished(victory: bool, kills: int, seconds: float, earned_gold: int)

const DURATION := 180.0
const BOSS_AT := 150.0
const MAX_ENEMIES := 80
const WORLD_TILE := 96.0
const COLORS := {
    "slime": Color("89d96f"),
    "bat": Color("d79cff"),
    "golem": Color("d8a17b"),
    "boss": Color("ef696b"),
}
const ENEMY_STATS := [
    {"name": "slime", "hp": 24.0, "speed": 65.0, "damage": 8.0, "radius": 16.0, "xp": 6.0, "gold": 1},
    {"name": "bat", "hp": 15.0, "speed": 115.0, "damage": 5.0, "radius": 13.0, "xp": 7.0, "gold": 1},
    {"name": "golem", "hp": 90.0, "speed": 40.0, "damage": 15.0, "radius": 22.0, "xp": 18.0, "gold": 3},
    {"name": "boss", "hp": 1200.0, "speed": 55.0, "damage": 20.0, "radius": 37.0, "xp": 100.0, "gold": 60},
]

var rng := RandomNumberGenerator.new()
var running := false
var paused := false
var auto_mode := true
var elapsed := 0.0
var kills := 0
var earned_gold := 0
var player_pos := Vector2.ZERO
var hp := 100.0
var max_hp := 100.0
var attack := 14.0
var move_speed := 190.0
var attack_interval := 0.8
var attack_timer := 0.0
var level := 1
var xp := 0.0
var xp_needed := 20.0
var projectile_count := 1
var orbit_level := 0
var orbit_angle := 0.0
var spawn_timer := 0.0
var boss_spawned := false
var invulnerable_flash := 0.0
var enemies: Array[Dictionary] = []
var projectiles: Array[Dictionary] = []
var gems: Array[Dictionary] = []
var particles: Array[Dictionary] = []
var _manual_direction := Vector2.ZERO
var _mouse_held := false
var _touch_index := -1
var _touch_start := Vector2.ZERO
var _touch_now := Vector2.ZERO
var _world_seed := 8

func _ready() -> void:
    mouse_filter = Control.MOUSE_FILTER_IGNORE
    rng.randomize()
    set_process(false)
    set_process_input(true)

func start_run(attack_level: int, health_level: int) -> void:
    elapsed = 0.0
    kills = 0
    earned_gold = 0
    player_pos = Vector2.ZERO
    attack = 14.0 + 3.0 * float(attack_level)
    max_hp = 100.0 + 15.0 * float(health_level)
    hp = max_hp
    move_speed = 190.0
    attack_interval = 0.8
    attack_timer = 0.1
    level = 1
    xp = 0.0
    xp_needed = 20.0
    projectile_count = 1
    orbit_level = 0
    orbit_angle = 0.0
    spawn_timer = 0.3
    boss_spawned = false
    invulnerable_flash = 0.0
    enemies.clear()
    projectiles.clear()
    gems.clear()
    particles.clear()
    _touch_index = -1
    _mouse_held = false
    auto_mode = true
    running = true
    paused = false
    visible = true
    set_process(true)
    queue_redraw()

func stop_run() -> void:
    running = false
    paused = false
    set_process(false)
    visible = false

func set_paused(value: bool) -> void:
    paused = value
    queue_redraw()

func _process(delta: float) -> void:
    if not running or paused:
        return
    delta = minf(delta, 0.05)
    elapsed += delta
    invulnerable_flash = maxf(0.0, invulnerable_flash - delta)
    orbit_angle += delta * 3.3
    _update_player(delta)
    _spawn_wave(delta)
    _update_enemies(delta)
    _fire_weapon(delta)
    _update_projectiles(delta)
    if not running:
        queue_redraw()
        return
    _update_orbit_blades(delta)
    if not running:
        queue_redraw()
        return
    _collect_gems(delta)
    _update_particles(delta)
    if hp <= 0.0:
        _finish(false)
    elif elapsed >= DURATION:
        _finish(false)
    queue_redraw()

func _update_player(delta: float) -> void:
    var direction := Vector2.ZERO
    if auto_mode:
        # Avoid the crowd first; otherwise pick up nearby XP crystals.
        var nearest_dist := INF
        var closest_enemy := Vector2.ZERO
        var danger_push := Vector2.ZERO
        for enemy in enemies:
            var difference: Vector2 = player_pos - enemy["p"]
            var dist := difference.length()
            if dist < nearest_dist:
                nearest_dist = dist
                closest_enemy = enemy["p"]
            if dist < 145.0 and dist > 0.1:
                danger_push += difference.normalized() * (145.0 - dist) / 145.0
        if danger_push.length() > 0.08:
            var tangent := Vector2(-danger_push.y, danger_push.x)
            direction = (danger_push.normalized() * 0.85 + tangent * 0.55).normalized()
        else:
            var gem_dist := 290.0
            for gem in gems:
                var dist := player_pos.distance_to(gem["p"])
                if dist < gem_dist:
                    gem_dist = dist
                    direction = (gem["p"] - player_pos).normalized()
            if direction == Vector2.ZERO and nearest_dist < 900.0:
                var toward_target: Vector2 = (closest_enemy - player_pos).normalized()
                if nearest_dist > 280.0:
                    # Walk into weapon range instead of fleeing forever.
                    direction = toward_target
                elif nearest_dist < 195.0:
                    direction = -toward_target * 0.50
                else:
                    # Strafe around enemies while staying in range.
                    direction = Vector2(-toward_target.y, toward_target.x) * 0.42
    else:
        direction = _manual_direction
        if Input.is_key_pressed(KEY_W) or Input.is_key_pressed(KEY_UP):
            direction.y -= 1.0
        if Input.is_key_pressed(KEY_S) or Input.is_key_pressed(KEY_DOWN):
            direction.y += 1.0
        if Input.is_key_pressed(KEY_A) or Input.is_key_pressed(KEY_LEFT):
            direction.x -= 1.0
        if Input.is_key_pressed(KEY_D) or Input.is_key_pressed(KEY_RIGHT):
            direction.x += 1.0
        direction = direction.limit_length(1.0)
    player_pos += direction * move_speed * delta

func _spawn_wave(delta: float) -> void:
    if elapsed >= BOSS_AT and not boss_spawned:
        boss_spawned = true
        _spawn_enemy(3)
    spawn_timer -= delta
    if spawn_timer > 0.0:
        return
    var intensity := 1.0 if elapsed < 60.0 else (1.7 if elapsed < 120.0 else 2.6)
    spawn_timer = 1.0 / intensity
    if enemies.size() >= MAX_ENEMIES:
        return
    var kind := 0
    if elapsed >= 120.0 and rng.randf() < 0.19:
        kind = 2
    elif elapsed >= 60.0 and rng.randf() < 0.38:
        kind = 1
    _spawn_enemy(kind)

func _spawn_enemy(kind: int) -> void:
    var info: Dictionary = ENEMY_STATS[kind]
    var angle := rng.randf_range(-PI, PI)
    var radius := maxf(size.x, size.y) * 0.6 + rng.randf_range(20.0, 90.0)
    var pos := player_pos + Vector2.RIGHT.rotated(angle) * radius
    enemies.append({
        "p": pos,
        "kind": kind,
        "hp": float(info["hp"]),
        "max_hp": float(info["hp"]),
        "speed": float(info["speed"]),
        "damage": float(info["damage"]),
        "radius": float(info["radius"]),
        "cd": rng.randf_range(0.0, 0.4),
        "sword_cd": 0.0,
    })

func _update_enemies(delta: float) -> void:
    for enemy in enemies:
        var pos: Vector2 = enemy["p"]
        var toward := player_pos - pos
        var distance := toward.length()
        var radius: float = enemy["radius"]
        if distance > radius + 10.0:
            pos += toward.normalized() * float(enemy["speed"]) * delta
            enemy["p"] = pos
        enemy["cd"] = maxf(0.0, float(enemy["cd"]) - delta)
        enemy["sword_cd"] = maxf(0.0, float(enemy["sword_cd"]) - delta)
        if distance < radius + 17.0 and float(enemy["cd"]) <= 0.0:
            hp -= float(enemy["damage"])
            invulnerable_flash = 0.22
            enemy["cd"] = 1.0
            _burst(player_pos, Color("ff737d"), 3)

func _fire_weapon(delta: float) -> void:
    attack_timer -= delta
    if attack_timer > 0.0:
        return
    var nearest := Vector2.ZERO
    var best := 330.0
    for enemy in enemies:
        var d := player_pos.distance_to(enemy["p"])
        if d < best:
            best = d
            nearest = enemy["p"]
    if best >= 330.0:
        attack_timer = 0.08
        return
    attack_timer = attack_interval
    var angle := (nearest - player_pos).angle()
    for i in range(projectile_count):
        var spread := (float(i) - float(projectile_count - 1) / 2.0) * 0.17
        projectiles.append({
            "p": player_pos + Vector2.RIGHT.rotated(angle + spread) * 20.0,
            "velocity": Vector2.RIGHT.rotated(angle + spread) * 640.0,
            "ttl": 1.0,
            "damage": attack,
        })

func _update_projectiles(delta: float) -> void:
    for i in range(projectiles.size() - 1, -1, -1):
        var bullet: Dictionary = projectiles[i]
        bullet["p"] = bullet["p"] + bullet["velocity"] * delta
        bullet["ttl"] = float(bullet["ttl"]) - delta
        if float(bullet["ttl"]) <= 0.0:
            projectiles.remove_at(i)
            continue
        var hit := false
        for j in range(enemies.size() - 1, -1, -1):
            if bullet["p"].distance_to(enemies[j]["p"]) < float(enemies[j]["radius"]) + 6.0:
                _damage_enemy(j, float(bullet["damage"]))
                if not running:
                    return
                hit = true
                break
        if hit:
            projectiles.remove_at(i)

func _update_orbit_blades(_delta: float) -> void:
    if orbit_level <= 0:
        return
    var blades := 2 + int(orbit_level >= 3)
    for blade in range(blades):
        var angle := orbit_angle + TAU * float(blade) / float(blades)
        var center := player_pos + Vector2.RIGHT.rotated(angle) * 66.0
        for j in range(enemies.size() - 1, -1, -1):
            if center.distance_to(enemies[j]["p"]) < float(enemies[j]["radius"]) + 14.0 and float(enemies[j]["sword_cd"]) <= 0.0:
                enemies[j]["sword_cd"] = 0.35
                _damage_enemy(j, 9.0 + 6.0 * float(orbit_level))
                if not running:
                    return

func _damage_enemy(index: int, damage: float) -> void:
    if index < 0 or index >= enemies.size():
        return
    var target: Dictionary = enemies[index]
    target["hp"] = float(target["hp"]) - damage
    _burst(target["p"], Color("f7d77a"), 2)
    if float(target["hp"]) > 0.0:
        return
    var kind: int = target["kind"]
    var info: Dictionary = ENEMY_STATS[kind]
    kills += 1
    earned_gold += int(info["gold"])
    gems.append({"p": target["p"], "xp": float(info["xp"])})
    _burst(target["p"], COLORS[str(info["name"])], 7)
    enemies.remove_at(index)
    if kind == 3:
        _finish(true)

func _collect_gems(delta: float) -> void:
    var found_level := false
    for i in range(gems.size() - 1, -1, -1):
        var gem: Dictionary = gems[i]
        var dist := player_pos.distance_to(gem["p"])
        if dist < 150.0 and dist > 0.01:
            gem["p"] = gem["p"].move_toward(player_pos, 315.0 * delta)
        if player_pos.distance_to(gem["p"]) < 40.0:
            xp += float(gem["xp"])
            gems.remove_at(i)
            if xp >= xp_needed:
                found_level = true
    if found_level:
        xp -= xp_needed
        level += 1
        xp_needed = 20.0 + float(level - 1) * 14.0
        paused = true
        level_up_requested.emit()

func _burst(position: Vector2, color: Color, count: int) -> void:
    for i in range(count):
        if particles.size() >= 115:
            return
        particles.append({
            "p": position,
            "vel": Vector2.RIGHT.rotated(rng.randf_range(-PI, PI)) * rng.randf_range(35.0, 105.0),
            "life": rng.randf_range(0.15, 0.4),
            "color": color,
        })

func _update_particles(delta: float) -> void:
    for i in range(particles.size() - 1, -1, -1):
        particles[i]["life"] = float(particles[i]["life"]) - delta
        particles[i]["p"] = particles[i]["p"] + particles[i]["vel"] * delta
        if float(particles[i]["life"]) <= 0.0:
            particles.remove_at(i)

func available_upgrades() -> Array[String]:
    var pool: Array[String] = ["rapid", "multishot", "orbit", "speed"]
    pool.shuffle()
    var choices: Array[String] = []
    for id in pool:
        if id == "rapid" and attack_interval <= 0.26:
            continue
        if id == "multishot" and projectile_count >= 5:
            continue
        if id == "orbit" and orbit_level >= 5:
            continue
        if id == "speed" and move_speed >= 350.0:
            continue
        choices.append(id)
        if choices.size() >= 3:
            break
    return choices

func apply_upgrade(id: String) -> void:
    match id:
        "rapid":
            attack_interval = maxf(0.26, attack_interval / 1.20)
        "multishot":
            projectile_count = mini(5, projectile_count + 1)
        "orbit":
            orbit_level = mini(5, orbit_level + 1)
        "speed":
            move_speed = minf(350.0, move_speed * 1.10)
    paused = false

func _finish(win: bool) -> void:
    if not running:
        return
    running = false
    paused = true
    set_process(false)
    battle_finished.emit(win, kills, elapsed, earned_gold)

func _input(event: InputEvent) -> void:
    if not running or paused or auto_mode:
        return
    if event is InputEventScreenTouch:
        if event.pressed and _touch_index == -1 and event.position.x < size.x * 0.7:
            _touch_index = event.index
            _touch_start = event.position
            _touch_now = event.position
        elif not event.pressed and event.index == _touch_index:
            _touch_index = -1
            _manual_direction = Vector2.ZERO
    elif event is InputEventScreenDrag and event.index == _touch_index:
        _touch_now = event.position
        _manual_direction = (_touch_now - _touch_start).limit_length(64.0) / 64.0
    elif event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
        if event.pressed and event.position.x < size.x * 0.7:
            _mouse_held = true
            _touch_start = event.position
            _touch_now = event.position
        else:
            _mouse_held = false
            _manual_direction = Vector2.ZERO
    elif event is InputEventMouseMotion and _mouse_held:
        _touch_now = event.position
        _manual_direction = (_touch_now - _touch_start).limit_length(64.0) / 64.0

func _draw() -> void:
    var center := size * 0.5
    draw_rect(Rect2(Vector2.ZERO, size), Color("172c31"))
    _draw_ground(center)
    for gem in gems:
        var p: Vector2 = gem["p"] - player_pos + center
        if _is_near_screen(p, 30.0):
            var diamond := PackedVector2Array([p + Vector2(0,-9),p + Vector2(8,0),p + Vector2(0,9),p + Vector2(-8,0)])
            draw_colored_polygon(diamond, Color("55dbfb"))
            draw_circle(p, 2.5, Color("e9ffff"))
    for bullet in projectiles:
        var p: Vector2 = bullet["p"] - player_pos + center
        if _is_near_screen(p, 20.0):
            draw_circle(p, 9.0, Color(0.29,0.93,0.97,0.20))
            draw_circle(p, 4.4, Color("96efff"))
    for enemy in enemies:
        var p: Vector2 = enemy["p"] - player_pos + center
        if _is_near_screen(p, 65.0):
            _draw_enemy(enemy, p)
    if orbit_level > 0:
        var count := 2 + int(orbit_level >= 3)
        draw_arc(center,66.0,0,TAU,68,Color(0.47,0.86,0.94,0.25),2.0)
        for i in range(count):
            var sword_pos := center + Vector2.RIGHT.rotated(orbit_angle + TAU * float(i)/float(count)) * 66.0
            draw_circle(sword_pos,15.0,Color(0.38,0.91,1.0,0.15))
            var poly := PackedVector2Array([sword_pos + Vector2(0,-16), sword_pos + Vector2(7,0), sword_pos + Vector2(0,16), sword_pos + Vector2(-7,0)])
            draw_colored_polygon(poly,Color("b3e8fa"))
    _draw_player(center)
    for particle in particles:
        var p: Vector2 = particle["p"] - player_pos + center
        if _is_near_screen(p, 6.0):
            var color: Color = particle["color"]
            color.a = clampf(float(particle["life"]) * 3.0,0.0,1.0)
            draw_circle(p,3.0,color)
    if not auto_mode and (_touch_index >= 0 or _mouse_held):
        draw_circle(_touch_start,58.0,Color(0.67,0.85,0.86,0.25),false,3.0)
        draw_circle(_touch_start + _manual_direction*45.0,22.0,Color(0.56,0.93,0.86,0.6))

func _is_near_screen(pos: Vector2, margin: float) -> bool:
    return pos.x > -margin and pos.y > -margin and pos.x < size.x + margin and pos.y < size.y + margin

func _draw_ground(center: Vector2) -> void:
    var origin := player_pos - center
    var first_x := int(floor(origin.x / WORLD_TILE)) - 1
    var first_y := int(floor(origin.y / WORLD_TILE)) - 1
    var cols := int(ceil(size.x / WORLD_TILE)) + 3
    var rows := int(ceil(size.y / WORLD_TILE)) + 3
    for ix in range(first_x, first_x + cols):
        for iy in range(first_y, first_y + rows):
            var p := Vector2(float(ix)*WORLD_TILE, float(iy)*WORLD_TILE) - origin
            var checker := (abs(ix + iy) % 2) == 0
            draw_rect(Rect2(p,Vector2(WORLD_TILE,WORLD_TILE)),Color("213f3e") if checker else Color("234441"))
            # Deterministic terrain details (avoid random visual flicker).
            var hash_v := posmod(ix * 37 + iy * 83 + ix * iy * 7 + _world_seed, 103)
            if hash_v < 26:
                var tuft := p + Vector2(20.0 + float(hash_v),35.0 + float(hash_v % 37))
                draw_line(tuft,tuft + Vector2(-4,-9),Color("3c6952"),2.0)
                draw_line(tuft,tuft + Vector2(4,-7),Color("4e7d5a"),2.0)
            if hash_v > 92:
                draw_circle(p + Vector2(62,55),5,Color("406461"))

func _draw_enemy(enemy: Dictionary, p: Vector2) -> void:
    var kind: int = enemy["kind"]
    var radius: float = enemy["radius"]
    draw_ellipse_shadow(p, radius)
    if kind == 0:
        draw_circle(p + Vector2(0,1),radius,Color("3b8462"))
        draw_circle(p + Vector2(0,-5),radius - 2.0,COLORS["slime"])
        draw_circle(p+Vector2(-5,-5),2.3,Color("163936"))
        draw_circle(p+Vector2(5,-5),2.3,Color("163936"))
    elif kind == 1:
        var wings := PackedVector2Array([p+Vector2(-25,1),p+Vector2(-8,-10),p,p+Vector2(8,-10),p+Vector2(25,1),p+Vector2(12,10),p+Vector2(0,4),p+Vector2(-12,10)])
        draw_colored_polygon(wings,COLORS["bat"])
        draw_circle(p,8.0,Color("654f91"))
        draw_circle(p+Vector2(-3,0),2.0,Color("ffdd80"))
        draw_circle(p+Vector2(3,0),2.0,Color("ffdd80"))
    elif kind == 2:
        draw_rect(Rect2(p-Vector2(19,17),Vector2(38,34)),Color("8e6057"))
        draw_rect(Rect2(p-Vector2(16,20),Vector2(32,28)),COLORS["golem"])
        draw_rect(Rect2(p+Vector2(-9,-5),Vector2(5,4)),Color("3c322e"))
        draw_rect(Rect2(p+Vector2(5,-5),Vector2(5,4)),Color("3c322e"))
    else:
        draw_circle(p,41.0,Color(0.97,0.32,0.42,0.22))
        draw_circle(p,35.0,Color("873c5b"))
        draw_circle(p + Vector2(0,-6),30.0,COLORS["boss"])
        draw_colored_polygon(PackedVector2Array([p+Vector2(-25,-18),p+Vector2(-30,-50),p+Vector2(-6,-30)]), Color("f6c27b"))
        draw_colored_polygon(PackedVector2Array([p+Vector2(25,-18),p+Vector2(30,-50),p+Vector2(6,-30)]), Color("f6c27b"))
        draw_circle(p + Vector2(-11,-8),4.0,Color("fff4aa"))
        draw_circle(p + Vector2(11,-8),4.0,Color("fff4aa"))
    var ratio := clampf(float(enemy["hp"]) / float(enemy["max_hp"]),0.0,1.0)
    if ratio < 0.98 or kind == 3:
        var w := radius * 2.4
        draw_rect(Rect2(p + Vector2(-w*0.5,-radius-16),Vector2(w,4)),Color("20242e"))
        draw_rect(Rect2(p + Vector2(-w*0.5,-radius-16),Vector2(w*ratio,4)),Color("ff8790"))

func draw_ellipse_shadow(p: Vector2, radius: float) -> void:
    draw_set_transform(p + Vector2(0,radius*0.8),0.0,Vector2(1.0,0.28))
    draw_circle(Vector2.ZERO,radius,Color(0.02,0.08,0.09,0.35))
    draw_set_transform(Vector2.ZERO)

func _draw_player(center: Vector2) -> void:
    draw_ellipse_shadow(center,20.0)
    if invulnerable_flash > 0.0:
        draw_circle(center,29.0,Color(1.0,0.42,0.53,0.35))
    draw_circle(center,23.0,Color(0.23,0.78,0.80,0.16))
    var cloak := PackedVector2Array([center+Vector2(0,-20),center+Vector2(19,13),center+Vector2(0,25),center+Vector2(-19,13)])
    draw_colored_polygon(cloak,Color("4772ac"))
    draw_circle(center+Vector2(0,-9),12,Color("e7c69e"))
    draw_arc(center+Vector2(0,-9),12.0,3.3,6.15,16,Color("222c4d"),6.0)
    draw_line(center+Vector2(17,2),center+Vector2(32,-17),Color("c9e8f4"),5.0)
    draw_circle(center+Vector2(16,5),4,Color("e8c65b"))
