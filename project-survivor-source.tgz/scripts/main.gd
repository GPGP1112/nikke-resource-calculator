extends Control
## Prototype 0.1: lobby, battle HUD, upgrades, offline rewards, save.

const BattleScript = preload("res://scripts/battle.gd")
const Save = preload("res://scripts/save_manager.gd")
const INK := Color("e8f3f1")
const MUTED := Color("95b2b2")
const PANEL := Color("172a36")
const ACCENT := Color("55dec0")
const GOLD := Color("f3ce75")

var data: Dictionary
var battle
var lobby: Control
var hud: Control
var modal: ColorRect
var modal_content: VBoxContainer
var gold_label: Label
var attack_description: Label
var health_description: Label
var attack_button: Button
var health_button: Button
var claim_button: Button
var stage_label: Label
var time_label: Label
var hp_label: Label
var xp_label: Label
var kill_label: Label
var hp_bar: ProgressBar
var xp_bar: ProgressBar
var mode_button: Button
var pause_button: Button
var autosave: Timer
var hud_tick := 0.0
var in_battle := false

func _ready() -> void:
    data = Save.load_data()
    battle = BattleScript.new()
    battle.name = "BattleView"
    add_child(battle)
    _fill(battle)
    battle.level_up_requested.connect(_show_levelup)
    battle.battle_finished.connect(_show_results)
    battle.visible = false
    _build_lobby()
    _build_hud()
    _build_modal()
    _refresh_lobby()
    autosave = Timer.new()
    autosave.wait_time = 15.0
    autosave.autostart = true
    autosave.timeout.connect(_save)
    add_child(autosave)
    set_process(true)

func _process(delta: float) -> void:
    if not in_battle:
        return
    hud_tick += delta
    if hud_tick >= 0.12:
        hud_tick = 0.0
        _refresh_hud()

func _notification(what: int) -> void:
    if what == NOTIFICATION_WM_CLOSE_REQUEST or what == NOTIFICATION_APPLICATION_PAUSED:
        if not data.is_empty():
            _save()

func _exit_tree() -> void:
    if not data.is_empty():
        _save()

func _fill(node: Control) -> void:
    node.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

func _save() -> void:
    Save.write_data(data)

func _style(bg: Color, edge: Color = Color.TRANSPARENT, corners: int = 18) -> StyleBoxFlat:
    var s := StyleBoxFlat.new()
    s.bg_color = bg
    s.border_color = edge
    s.set_border_width_all(1 if edge.a > 0.0 else 0)
    s.set_corner_radius_all(corners)
    s.content_margin_left = 17.0
    s.content_margin_right = 17.0
    s.content_margin_top = 14.0
    s.content_margin_bottom = 14.0
    return s

func _label(value: String, font_size: int = 20, color: Color = INK, alignment: HorizontalAlignment = HORIZONTAL_ALIGNMENT_LEFT) -> Label:
    var result := Label.new()
    result.text = value
    result.horizontal_alignment = alignment
    result.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
    result.add_theme_font_size_override("font_size", font_size)
    result.add_theme_color_override("font_color", color)
    return result

func _button(value: String, tint: Color = ACCENT, light_text: bool = false) -> Button:
    var result := Button.new()
    result.text = value
    result.custom_minimum_size.y = 60.0
    result.focus_mode = Control.FOCUS_NONE
    result.add_theme_font_size_override("font_size", 20)
    result.add_theme_color_override("font_color", Color("102333") if not light_text else INK)
    result.add_theme_color_override("font_hover_color", Color("102333") if not light_text else INK)
    result.add_theme_color_override("font_pressed_color", INK)
    result.add_theme_color_override("font_disabled_color", MUTED)
    result.add_theme_stylebox_override("normal", _style(tint))
    result.add_theme_stylebox_override("hover", _style(tint.lightened(0.13)))
    result.add_theme_stylebox_override("pressed", _style(tint.darkened(0.20)))
    result.add_theme_stylebox_override("disabled", _style(Color("2c4149")))
    return result

func _card(parent: Node, color: Color = PANEL) -> VBoxContainer:
    var panel := PanelContainer.new()
    panel.add_theme_stylebox_override("panel", _style(color, Color("304b58")))
    parent.add_child(panel)
    var v := VBoxContainer.new()
    v.add_theme_constant_override("separation", 8)
    panel.add_child(v)
    return v

func _space(parent: Node, height: float) -> void:
    var spacer := Control.new()
    spacer.custom_minimum_size.y = height
    spacer.mouse_filter = Control.MOUSE_FILTER_IGNORE
    parent.add_child(spacer)

func _build_lobby() -> void:
    lobby = Control.new()
    lobby.name = "Lobby"
    add_child(lobby)
    _fill(lobby)
    var background := ColorRect.new()
    background.color = Color("0d1c29")
    lobby.add_child(background)
    _fill(background)
    var margin := MarginContainer.new()
    lobby.add_child(margin)
    _fill(margin)
    margin.add_theme_constant_override("margin_left", 27)
    margin.add_theme_constant_override("margin_right", 27)
    margin.add_theme_constant_override("margin_top", 20)
    margin.add_theme_constant_override("margin_bottom", 20)
    var center := CenterContainer.new()
    margin.add_child(center)
    var content := VBoxContainer.new()
    content.custom_minimum_size.x = 400
    content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    content.add_theme_constant_override("separation", 12)
    center.add_child(content)
    var glyph := _label("✦  S U R V I V E  ✦", 20, ACCENT, HORIZONTAL_ALIGNMENT_CENTER)
    content.add_child(glyph)
    var name := _label("PROJECT\nSURVIVOR", 47, INK, HORIZONTAL_ALIGNMENT_CENTER)
    content.add_child(name)
    content.add_child(_label("AUTO-SURVIVAL  ·  IDLE RPG", 15, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
    _space(content, 17)
    var gold_card := _card(content)
    gold_card.add_child(_label("YOUR GOLD", 15, MUTED))
    gold_label = _label("0 G", 29, GOLD)
    gold_card.add_child(gold_label)
    _space(content, 8)
    var attack_card := _card(content)
    attack_card.add_child(_label("PERMANENT ATTACK", 18, INK))
    attack_description = _label("", 15, MUTED)
    attack_card.add_child(attack_description)
    attack_button = _button("UPGRADE ATTACK", Color("68b3da"))
    attack_button.pressed.connect(func() -> void: _buy_upgrade("attack"))
    attack_card.add_child(attack_button)
    var health_card := _card(content)
    health_card.add_child(_label("PERMANENT HEALTH", 18, INK))
    health_description = _label("", 15, MUTED)
    health_card.add_child(health_description)
    health_button = _button("UPGRADE HEALTH", Color("bb9ce9"))
    health_button.pressed.connect(func() -> void: _buy_upgrade("health"))
    health_card.add_child(health_button)
    claim_button = _button("CLAIM IDLE REWARD", Color("eec76c"))
    claim_button.pressed.connect(_claim_idle)
    content.add_child(claim_button)
    var play := _button("▶    START SURVIVAL", ACCENT)
    play.custom_minimum_size.y = 75
    play.add_theme_font_size_override("font_size", 24)
    play.pressed.connect(_start_battle)
    content.add_child(play)
    stage_label = _label("STAGE 1  ·  3-MINUTE SURVIVAL", 15, MUTED, HORIZONTAL_ALIGNMENT_CENTER)
    content.add_child(stage_label)

func _refresh_lobby() -> void:
    gold_label.text = "%d G" % int(data["gold"])
    var atk_level := int(data["attack_level"])
    var hp_level := int(data["health_level"])
    var atk_cost := Save.upgrade_cost(atk_level)
    var hp_cost := Save.upgrade_cost(hp_level)
    attack_description.text = "Level %d  ·  Attack %d → %d" % [atk_level, 14 + atk_level*3, 17 + atk_level*3]
    health_description.text = "Level %d  ·  HP %d → %d" % [hp_level, 100 + hp_level*15, 115 + hp_level*15]
    attack_button.text = "ATTACK +3   ·   %d G" % atk_cost
    health_button.text = "HEALTH +15   ·   %d G" % hp_cost
    attack_button.disabled = int(data["gold"]) < atk_cost
    health_button.disabled = int(data["gold"]) < hp_cost
    var pending := int(data["pending_idle"])
    claim_button.text = "CLAIM IDLE REWARD   +%d G" % pending if pending > 0 else "IDLE REWARD  ·  120 G / HR"
    claim_button.disabled = pending <= 0
    stage_label.text = "STAGE 1  ·  180 SEC   |   WINS %d" % int(data["wins"])

func _buy_upgrade(kind: String) -> void:
    var key := kind + "_level"
    var cost := Save.upgrade_cost(int(data[key]))
    if int(data["gold"]) < cost:
        return
    data["gold"] = int(data["gold"]) - cost
    data[key] = int(data[key]) + 1
    _save()
    _refresh_lobby()

func _claim_idle() -> void:
    var pending := int(data["pending_idle"])
    if pending <= 0:
        return
    data["gold"] = int(data["gold"]) + pending
    data["pending_idle"] = 0
    _save()
    _refresh_lobby()

func _build_hud() -> void:
    hud = Control.new()
    hud.name = "BattleHUD"
    hud.mouse_filter = Control.MOUSE_FILTER_IGNORE
    add_child(hud)
    _fill(hud)
    var top := VBoxContainer.new()
    top.anchor_right = 1.0
    top.offset_left = 23
    top.offset_right = -23
    top.offset_top = 24
    top.add_theme_constant_override("separation", 8)
    hud.add_child(top)
    var info_row := HBoxContainer.new()
    top.add_child(info_row)
    var title := _label("STAGE 1  ·  FORGOTTEN GROVE", 16, INK)
    title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    info_row.add_child(title)
    time_label = _label("03:00", 26, GOLD)
    info_row.add_child(time_label)
    hp_label = _label("HP 100 / 100", 16, INK)
    top.add_child(hp_label)
    hp_bar = _progress(Color("f17c83"))
    top.add_child(hp_bar)
    kill_label = _label("LV 1   ·   0 KILLS", 15, INK)
    top.add_child(kill_label)
    xp_bar = _progress(Color("70ddec"))
    top.add_child(xp_bar)
    xp_label = _label("XP  0 / 20", 14, MUTED)
    top.add_child(xp_label)
    var bottom := HBoxContainer.new()
    bottom.anchor_left = 0.0
    bottom.anchor_right = 1.0
    bottom.anchor_top = 1.0
    bottom.anchor_bottom = 1.0
    bottom.offset_left = 20
    bottom.offset_right = -20
    bottom.offset_top = -91
    bottom.offset_bottom = -18
    bottom.add_theme_constant_override("separation", 9)
    hud.add_child(bottom)
    mode_button = _button("AUTO: ON", Color("266a67"), true)
    mode_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    mode_button.pressed.connect(_toggle_auto)
    bottom.add_child(mode_button)
    pause_button = _button("PAUSE", Color("344858"), true)
    pause_button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    pause_button.pressed.connect(_toggle_pause)
    bottom.add_child(pause_button)
    var quit := _button("EXIT", Color("693e4b"), true)
    quit.size_flags_horizontal = Control.SIZE_EXPAND_FILL
    quit.pressed.connect(_exit_battle)
    bottom.add_child(quit)
    hud.visible = false

func _progress(tint: Color) -> ProgressBar:
    var bar := ProgressBar.new()
    bar.custom_minimum_size.y = 13
    bar.show_percentage = false
    bar.min_value = 0
    bar.max_value = 100
    bar.add_theme_stylebox_override("background", _style(Color("253b45"), Color.TRANSPARENT, 7))
    bar.add_theme_stylebox_override("fill", _style(tint, Color.TRANSPARENT, 7))
    return bar

func _refresh_hud() -> void:
    var seconds_left := maxi(0, int(ceil(180.0 - battle.elapsed)))
    time_label.text = "%02d:%02d" % [int(seconds_left/60),seconds_left%60]
    hp_label.text = "HP %d / %d" % [maxi(0,int(ceil(battle.hp))),int(battle.max_hp)]
    hp_bar.value = 100.0 * battle.hp / battle.max_hp
    kill_label.text = "LV %d    ·    %d KILLS    ·    %d G" % [battle.level,battle.kills,battle.earned_gold]
    xp_bar.value = 100.0 * battle.xp / battle.xp_needed
    xp_label.text = "XP  %d / %d" % [int(battle.xp),int(battle.xp_needed)]
    mode_button.text = "AUTO: ON" if battle.auto_mode else "MANUAL"
    pause_button.text = "RESUME" if battle.paused else "PAUSE"

func _toggle_auto() -> void:
    if not in_battle or modal.visible:
        return
    battle.auto_mode = not battle.auto_mode
    battle._manual_direction = Vector2.ZERO
    _refresh_hud()

func _toggle_pause() -> void:
    if not in_battle or modal.visible:
        return
    battle.set_paused(not battle.paused)
    _refresh_hud()

func _exit_battle() -> void:
    if not in_battle or modal.visible:
        return
    battle._finish(false)

func _start_battle() -> void:
    lobby.visible = false
    in_battle = true
    battle.start_run(int(data["attack_level"]), int(data["health_level"]))
    hud.visible = true
    modal.visible = false
    _refresh_hud()

func _build_modal() -> void:
    modal = ColorRect.new()
    modal.color = Color(0.015,0.035,0.055,0.85)
    modal.mouse_filter = Control.MOUSE_FILTER_STOP
    add_child(modal)
    _fill(modal)
    var center := CenterContainer.new()
    modal.add_child(center)
    _fill(center)
    var panel := PanelContainer.new()
    panel.custom_minimum_size.x = 440
    panel.add_theme_stylebox_override("panel", _style(Color("172e3d"),Color("62a7a4"),22))
    center.add_child(panel)
    modal_content = VBoxContainer.new()
    modal_content.add_theme_constant_override("separation", 14)
    panel.add_child(modal_content)
    modal.visible = false

func _clear_modal() -> void:
    for child in modal_content.get_children():
        modal_content.remove_child(child)
        child.queue_free()

func _show_levelup() -> void:
    if not in_battle:
        return
    _clear_modal()
    modal_content.add_child(_label("✦  LEVEL UP!  ✦", 31, GOLD, HORIZONTAL_ALIGNMENT_CENTER))
    modal_content.add_child(_label("CHOOSE ONE UPGRADE", 17, MUTED, HORIZONTAL_ALIGNMENT_CENTER))
    var choices: Array[String] = battle.available_upgrades()
    if choices.is_empty():
        battle.set_paused(false)
        return
    var descriptions := {
        "rapid": "RAPID FIRE   ·   +20% attack speed",
        "multishot": "MULTISHOT   ·   +1 projectile",
        "orbit": "ORBIT BLADES   ·   spinning sword damage",
        "speed": "SWIFT BOOTS   ·   +10% movement speed",
    }
    for id in choices:
        var choice := _button(descriptions[id], Color("31586c"), true)
        choice.custom_minimum_size.y = 80
        choice.add_theme_font_size_override("font_size", 17)
        choice.pressed.connect(_choose_upgrade.bind(id))
        modal_content.add_child(choice)
    modal.visible = true
    _refresh_hud()

func _choose_upgrade(id: String) -> void:
    modal.visible = false
    battle.apply_upgrade(id)
    _refresh_hud()

func _show_results(victory: bool, total_kills: int, seconds: float, gold_earned: int) -> void:
    if not in_battle:
        return
    data["gold"] = int(data["gold"]) + gold_earned
    if victory:
        data["wins"] = int(data["wins"]) + 1
    _save()
    _clear_modal()
    var heading := "STAGE CLEARED!" if victory else "SURVIVAL ENDED"
    modal_content.add_child(_label(heading, 31, ACCENT if victory else GOLD,HORIZONTAL_ALIGNMENT_CENTER))
    modal_content.add_child(_label("Time   %02d:%02d" % [int(seconds/60.0),int(seconds)%60], 21, INK, HORIZONTAL_ALIGNMENT_CENTER))
    modal_content.add_child(_label("Monsters defeated   %d" % total_kills, 21, INK, HORIZONTAL_ALIGNMENT_CENTER))
    modal_content.add_child(_label("Gold earned   +%d G" % gold_earned, 25, GOLD,HORIZONTAL_ALIGNMENT_CENTER))
    var again := _button("RETRY BATTLE", ACCENT)
    again.pressed.connect(func() -> void:
        modal.visible = false
        battle.start_run(int(data["attack_level"]),int(data["health_level"]))
        _refresh_hud()
    )
    modal_content.add_child(again)
    var home := _button("RETURN TO LOBBY", Color("344858"), true)
    home.pressed.connect(_return_lobby)
    modal_content.add_child(home)
    modal.visible = true
    _refresh_hud()

func _return_lobby() -> void:
    battle.stop_run()
    in_battle = false
    modal.visible = false
    hud.visible = false
    lobby.visible = true
    _refresh_lobby()
